#include <stdio.h>
void main()
{
 /** on cree des valeurs */
    int a;
    int b;
    int c;
    int d;
    int e;
/** on demande les valeurs de a, b a l'utilisateur */
    printf("Nombre 1 : ");
    scanf("%d", &a);
    printf("Nombre 2 : ");
    scanf("%d", &b);
    printf("Nombre 3 : ");
    scanf("%d", &c);
    printf("Nombre 4 : ");
    scanf("%d", &d);
    e = a + b + c + d;
    printf("Somme :%d\n",e);
}

